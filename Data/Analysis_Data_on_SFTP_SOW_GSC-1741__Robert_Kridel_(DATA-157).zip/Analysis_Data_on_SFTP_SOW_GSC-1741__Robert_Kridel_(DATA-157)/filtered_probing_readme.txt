The following probing results have been generated using probing-0.5.1.1 and three different threshold of alignment between probe and reads parameters - 34,36 and 38.  The spreadsheet contains the variant name, 
the number of libraries that contain evidence of that of that variant, and a comma separated list of libraries that contain that variant:
param34_events_tracking.csv
param36_events_tracking.csv
param38_events_tracking.csv

